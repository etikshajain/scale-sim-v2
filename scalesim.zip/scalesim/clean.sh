rm -rf *.csv
rm -rf outputs/*